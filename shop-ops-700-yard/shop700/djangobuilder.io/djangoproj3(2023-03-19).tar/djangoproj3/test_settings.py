
from djangoproj3.settings import *  # noqa

# Override any settings required for tests here
