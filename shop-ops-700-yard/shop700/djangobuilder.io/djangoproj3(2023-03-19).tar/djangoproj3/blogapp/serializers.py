from rest_framework import serializers

from . import models


class CategorytblSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Categorytbl
        fields = [
            "created",
            "name",
            "last_updated",
        ]

class PostSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Post
        fields = [
            "created_at",
            "body",
            "title",
            "updated_at",
            "category",
        ]
