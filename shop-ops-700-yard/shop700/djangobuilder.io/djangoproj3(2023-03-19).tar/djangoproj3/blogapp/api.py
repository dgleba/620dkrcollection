from rest_framework import viewsets, permissions

from . import serializers
from . import models


class CategorytblViewSet(viewsets.ModelViewSet):
    """ViewSet for the Categorytbl class"""

    queryset = models.Categorytbl.objects.all()
    serializer_class = serializers.CategorytblSerializer
    permission_classes = [permissions.IsAuthenticated]


class PostViewSet(viewsets.ModelViewSet):
    """ViewSet for the Post class"""

    queryset = models.Post.objects.all()
    serializer_class = serializers.PostSerializer
    permission_classes = [permissions.IsAuthenticated]
