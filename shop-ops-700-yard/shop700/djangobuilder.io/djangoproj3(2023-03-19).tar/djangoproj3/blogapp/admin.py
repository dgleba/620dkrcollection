from django.contrib import admin
from django import forms

from . import models


class CategorytblAdminForm(forms.ModelForm):

    class Meta:
        model = models.Categorytbl
        fields = "__all__"


class CategorytblAdmin(admin.ModelAdmin):
    form = CategorytblAdminForm
    list_display = [
        "created",
        "name",
        "last_updated",
    ]
    readonly_fields = [
        "created",
        "name",
        "last_updated",
    ]


class PostAdminForm(forms.ModelForm):

    class Meta:
        model = models.Post
        fields = "__all__"


class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    list_display = [
        "created_at",
        "body",
        "title",
        "updated_at",
    ]
    readonly_fields = [
        "created_at",
        "body",
        "title",
        "updated_at",
    ]


admin.site.register(models.Categorytbl, CategorytblAdmin)
admin.site.register(models.Post, PostAdmin)
