from django import forms
from blogapp.models import Categorytbl
from . import models


class CategorytblForm(forms.ModelForm):
    class Meta:
        model = models.Categorytbl
        fields = [
            "name",
        ]


class PostForm(forms.ModelForm):
    class Meta:
        model = models.Post
        fields = [
            "body",
            "title",
            "category",
        ]

    def __init__(self, *args, **kwargs):
        super(PostForm, self).__init__(*args, **kwargs)
        self.fields["category"].queryset = Categorytbl.objects.all()

