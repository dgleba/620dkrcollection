from rest_framework import serializers

from . import models


class MenumodelSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Menumodel
        fields = [
            "mcomment",
            "mstatus",
            "mlink",
            "updated_at",
            "msort",
            "mapplication",
            "mdescription",
            "created_at",
        ]
