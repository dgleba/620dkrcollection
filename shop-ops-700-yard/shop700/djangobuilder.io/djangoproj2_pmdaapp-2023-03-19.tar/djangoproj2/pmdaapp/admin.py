from django.contrib import admin
from django import forms

from . import models


class MenumodelAdminForm(forms.ModelForm):

    class Meta:
        model = models.Menumodel
        fields = "__all__"


class MenumodelAdmin(admin.ModelAdmin):
    form = MenumodelAdminForm
    list_display = [
        "mcomment",
        "mstatus",
        "mlink",
        "updated_at",
        "msort",
        "mapplication",
        "mdescription",
        "created_at",
    ]
    readonly_fields = [
        "mcomment",
        "mstatus",
        "mlink",
        "updated_at",
        "msort",
        "mapplication",
        "mdescription",
        "created_at",
    ]


admin.site.register(models.Menumodel, MenumodelAdmin)
