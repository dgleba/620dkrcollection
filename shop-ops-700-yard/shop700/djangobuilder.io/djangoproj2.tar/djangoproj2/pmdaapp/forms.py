from django import forms
from . import models


class MenumodelForm(forms.ModelForm):
    class Meta:
        model = models.Menumodel
        fields = [
            "mlink",
            "mapplication",
            "mcomment",
            "msort",
            "mstatus",
            "mdescription",
        ]
