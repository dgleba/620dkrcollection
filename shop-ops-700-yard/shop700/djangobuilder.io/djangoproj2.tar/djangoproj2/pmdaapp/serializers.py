from rest_framework import serializers

from . import models


class MenumodelSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Menumodel
        fields = [
            "mlink",
            "mapplication",
            "created_at",
            "mcomment",
            "msort",
            "mstatus",
            "mdescription",
            "updated_at",
        ]
