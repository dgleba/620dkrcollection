from django.urls import path, include
from rest_framework import routers

from . import api
from . import views
from . import htmx


router = routers.DefaultRouter()
router.register("Menumodel", api.MenumodelViewSet)

urlpatterns = (
    path("api/v1/", include(router.urls)),
    path("pmdaapp/Menumodel/", views.MenumodelListView.as_view(), name="pmdaapp_Menumodel_list"),
    path("pmdaapp/Menumodel/create/", views.MenumodelCreateView.as_view(), name="pmdaapp_Menumodel_create"),
    path("pmdaapp/Menumodel/detail/<int:pk>/", views.MenumodelDetailView.as_view(), name="pmdaapp_Menumodel_detail"),
    path("pmdaapp/Menumodel/update/<int:pk>/", views.MenumodelUpdateView.as_view(), name="pmdaapp_Menumodel_update"),
    path("pmdaapp/Menumodel/delete/<int:pk>/", views.MenumodelDeleteView.as_view(), name="pmdaapp_Menumodel_delete"),

    path("pmdaapp/htmx/Menumodel/", htmx.HTMXMenumodelListView.as_view(), name="pmdaapp_Menumodel_htmx_list"),
    path("pmdaapp/htmx/Menumodel/create/", htmx.HTMXMenumodelCreateView.as_view(), name="pmdaapp_Menumodel_htmx_create"),
    path("pmdaapp/htmx/Menumodel/delete/<int:pk>/", htmx.HTMXMenumodelDeleteView.as_view(), name="pmdaapp_Menumodel_htmx_delete"),
)
