from django.contrib import admin
from django import forms

from . import models


class MenumodelAdminForm(forms.ModelForm):

    class Meta:
        model = models.Menumodel
        fields = "__all__"


class MenumodelAdmin(admin.ModelAdmin):
    form = MenumodelAdminForm
    list_display = [
        "mlink",
        "mapplication",
        "created_at",
        "mcomment",
        "msort",
        "mstatus",
        "mdescription",
        "updated_at",
    ]
    readonly_fields = [
        "mlink",
        "mapplication",
        "created_at",
        "mcomment",
        "msort",
        "mstatus",
        "mdescription",
        "updated_at",
    ]


admin.site.register(models.Menumodel, MenumodelAdmin)
