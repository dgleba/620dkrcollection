from django.contrib import admin
from django import forms

from . import models


class PostAdminForm(forms.ModelForm):

    class Meta:
        model = models.Post
        fields = "__all__"


class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    list_display = [
        "last_updated",
        "body",
        "title",
        "created",
    ]
    readonly_fields = [
        "last_updated",
        "body",
        "title",
        "created",
    ]


admin.site.register(models.Post, PostAdmin)
