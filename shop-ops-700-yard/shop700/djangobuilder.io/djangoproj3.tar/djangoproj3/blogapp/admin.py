from django.contrib import admin
from django import forms

from . import models


class CategorytblAdminForm(forms.ModelForm):

    class Meta:
        model = models.Categorytbl
        fields = "__all__"


class CategorytblAdmin(admin.ModelAdmin):
    form = CategorytblAdminForm
    list_display = [
        "last_updated",
        "created",
        "name",
    ]
    readonly_fields = [
        "last_updated",
        "created",
        "name",
    ]


class PostAdminForm(forms.ModelForm):

    class Meta:
        model = models.Post
        fields = "__all__"


class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    list_display = [
        "title",
        "updated_at",
        "created_at",
        "body",
    ]
    readonly_fields = [
        "title",
        "updated_at",
        "created_at",
        "body",
    ]


admin.site.register(models.Categorytbl, CategorytblAdmin)
admin.site.register(models.Post, PostAdmin)
