from django.urls import path, include
from rest_framework import routers

from . import api
from . import views
from . import htmx


router = routers.DefaultRouter()
router.register("Categorytbl", api.CategorytblViewSet)
router.register("Post", api.PostViewSet)

urlpatterns = (
    path("api/v1/", include(router.urls)),
    path("blogapp/Categorytbl/", views.CategorytblListView.as_view(), name="blogapp_Categorytbl_list"),
    path("blogapp/Categorytbl/create/", views.CategorytblCreateView.as_view(), name="blogapp_Categorytbl_create"),
    path("blogapp/Categorytbl/detail/<int:pk>/", views.CategorytblDetailView.as_view(), name="blogapp_Categorytbl_detail"),
    path("blogapp/Categorytbl/update/<int:pk>/", views.CategorytblUpdateView.as_view(), name="blogapp_Categorytbl_update"),
    path("blogapp/Categorytbl/delete/<int:pk>/", views.CategorytblDeleteView.as_view(), name="blogapp_Categorytbl_delete"),
    path("blogapp/Post/", views.PostListView.as_view(), name="blogapp_Post_list"),
    path("blogapp/Post/create/", views.PostCreateView.as_view(), name="blogapp_Post_create"),
    path("blogapp/Post/detail/<int:pk>/", views.PostDetailView.as_view(), name="blogapp_Post_detail"),
    path("blogapp/Post/update/<int:pk>/", views.PostUpdateView.as_view(), name="blogapp_Post_update"),
    path("blogapp/Post/delete/<int:pk>/", views.PostDeleteView.as_view(), name="blogapp_Post_delete"),

    path("blogapp/htmx/Categorytbl/", htmx.HTMXCategorytblListView.as_view(), name="blogapp_Categorytbl_htmx_list"),
    path("blogapp/htmx/Categorytbl/create/", htmx.HTMXCategorytblCreateView.as_view(), name="blogapp_Categorytbl_htmx_create"),
    path("blogapp/htmx/Categorytbl/delete/<int:pk>/", htmx.HTMXCategorytblDeleteView.as_view(), name="blogapp_Categorytbl_htmx_delete"),
    path("blogapp/htmx/Post/", htmx.HTMXPostListView.as_view(), name="blogapp_Post_htmx_list"),
    path("blogapp/htmx/Post/create/", htmx.HTMXPostCreateView.as_view(), name="blogapp_Post_htmx_create"),
    path("blogapp/htmx/Post/delete/<int:pk>/", htmx.HTMXPostDeleteView.as_view(), name="blogapp_Post_htmx_delete"),
)
