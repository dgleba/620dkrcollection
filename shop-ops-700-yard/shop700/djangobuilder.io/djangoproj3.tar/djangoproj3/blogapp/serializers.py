from rest_framework import serializers

from . import models


class CategorytblSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Categorytbl
        fields = [
            "last_updated",
            "created",
            "name",
        ]

class PostSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Post
        fields = [
            "title",
            "updated_at",
            "created_at",
            "body",
            "category",
        ]
