#!/bin/bash
timestamp=$(date +"%Y.%m.%d_%H.%M.%S_%Z") 
echo "contrab running run.sh - System path is $PATH at $timestamp. TESTVAR = $TESTVAR"
