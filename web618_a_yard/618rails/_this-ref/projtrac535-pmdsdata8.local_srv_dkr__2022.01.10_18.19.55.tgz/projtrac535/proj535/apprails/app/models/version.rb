class Version < ApplicationRecord
end
