//   usage:    powershell "node pup-ignitionreset.js | tee /srv/web/log/pup-ignitionresetlog.txt"

//   usage:   cd /srv/web/pupignitionreset; nohup node pup-ignitionresettrial.js | tee /srv/web/log/pup-ignitionresetlog.txt &

//
//      press the reset trial button if it exists every two minutes.
//
//      David Gleba 2019-05-14 06:21AM

const puppeteer = require("puppeteer");

const escapeXpathString = str => {
  const splitedQuotes = str.replace(/'/g, `', "'", '`);
  return `concat('${splitedQuotes}', '')`;
};

const clickByText = async (page, text) => {
  const escapedText = escapeXpathString(text);
  const linkHandlers = await page.$x(`//a[contains(text(), ${escapedText})]`);

  if (linkHandlers.length > 0) {
    console.log(
      " =======================   Found Reset Trial button   ======================"
    );
    await linkHandlers[0].click();
  } else {
    console.log(`Link not found: ${text}`);
  }
};

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const run = async () => {
  // const browser = await puppeteer.launch();
  // no-sandbox for docker
  const browser = await puppeteer.launch({
    args: ["--no-sandbox", "--disable-setuid-sandbox"]
  });
  const page = await browser.newPage();

  let i = 0;

  do {
    i++;
    let ts = Date();
    console.log(i, ts);

    // ignition web app url...

    // await page.goto("http://192.168.88.39:8088/web/signin"); // newer ignition version
    await page.goto("http://10.4.1.232:8088/main/web/signin"); // older version

    await page.screenshot({ path: "screenshotc3a.png" });

    // login..

    await page.waitFor('input[name="username"]');
    await page.type('input[name="username"]', "admin");

    // await page.type('input[name="password"]', "pas123");
    await page.type('input[name="password"]', "pmdsdata9");
    await page.click('[value="Sign In"]');

    await page.screenshot({ path: "screenshotc3b.png" });

    // Click `reset trial`..

    //console.log("Current page:", page.url());

    await clickByText(page, `Reset Trial`);

    await page.screenshot({ path: "screenshotc3c.png" });

    await sleep(60000);
    await sleep(58000);
  } while (true);

  return browser.close();
};

const logErrorAndExit = err => {
  console.log(err);
  process.exit();
};

run().catch(logErrorAndExit);
