
from djangoproj.settings import *  # noqa

# Override any settings required for tests here
