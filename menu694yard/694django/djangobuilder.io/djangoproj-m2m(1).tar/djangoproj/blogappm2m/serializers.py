from rest_framework import serializers

from . import models


class TagTblSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.TagTbl
        fields = [
            "name",
            "last_updated",
            "created",
        ]

class PostedFromTblSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PostedFromTbl
        fields = [
            "created",
            "last_updated",
            "name",
        ]

class PostingSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Posting
        fields = [
            "created_at",
            "updated_at",
            "body",
            "title",
            "postedfrom_id",
            "post_tag_mm",
        ]
