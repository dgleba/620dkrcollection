from django.db import models
from django.urls import reverse


class TagTbl(models.Model):

    # Fields
    name = models.CharField(max_length=302)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    created = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        pass

    def __str__(self):
        return str(self.name)

    def get_absolute_url(self):
        return reverse("blogappm2m_TagTbl_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("blogappm2m_TagTbl_update", args=(self.pk,))

    @staticmethod
    def get_htmx_create_url():
        return reverse("blogappm2m_TagTbl_htmx_create")

    def get_htmx_delete_url(self):
        return reverse("blogappm2m_TagTbl_htmx_delete", args=(self.pk,))


class PostedFromTbl(models.Model):

    # Fields
    created = models.DateTimeField(auto_now_add=True, editable=False)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    name = models.CharField(max_length=33)

    class Meta:
        pass

    def __str__(self):
        return str(self.name)

    def get_absolute_url(self):
        return reverse("blogappm2m_PostedFromTbl_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("blogappm2m_PostedFromTbl_update", args=(self.pk,))

    @staticmethod
    def get_htmx_create_url():
        return reverse("blogappm2m_PostedFromTbl_htmx_create")

    def get_htmx_delete_url(self):
        return reverse("blogappm2m_PostedFromTbl_htmx_delete", args=(self.pk,))


class Posting(models.Model):

    # Relationships
    postedfrom_id = models.ForeignKey("blogapp2.PostedFromTbl", on_delete=models.CASCADE)
    post_tag_mm = models.ManyToManyField("blogapp.Tagtbl")

    # Fields
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    updated_at = models.DateTimeField(auto_now=True, editable=False)
    body = models.TextField()
    title = models.CharField(max_length=330)

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("blogappm2m_Posting_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("blogappm2m_Posting_update", args=(self.pk,))

    @staticmethod
    def get_htmx_create_url():
        return reverse("blogappm2m_Posting_htmx_create")

    def get_htmx_delete_url(self):
        return reverse("blogappm2m_Posting_htmx_delete", args=(self.pk,))
