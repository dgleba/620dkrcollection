from django import forms
from blogapp2.models import PostedFromTbl
from blogapp.models import Tagtbl
from . import models


class TagTblForm(forms.ModelForm):
    class Meta:
        model = models.TagTbl
        fields = [
            "name",
        ]


class PostedFromTblForm(forms.ModelForm):
    class Meta:
        model = models.PostedFromTbl
        fields = [
            "name",
        ]


class PostingForm(forms.ModelForm):
    class Meta:
        model = models.Posting
        fields = [
            "body",
            "title",
            "postedfrom_id",
            "post_tag_mm",
        ]

    def __init__(self, *args, **kwargs):
        super(PostingForm, self).__init__(*args, **kwargs)
        self.fields["postedfrom_id"].queryset = PostedFromTbl.objects.all()
        self.fields["post_tag_mm"].queryset = Tagtbl.objects.all()

