from django.contrib import admin
from django import forms

from . import models


class TagTblAdminForm(forms.ModelForm):

    class Meta:
        model = models.TagTbl
        fields = "__all__"


class TagTblAdmin(admin.ModelAdmin):
    form = TagTblAdminForm
    list_display = [
        "name",
        "last_updated",
        "created",
    ]
    readonly_fields = [
        "name",
        "last_updated",
        "created",
    ]


class PostedFromTblAdminForm(forms.ModelForm):

    class Meta:
        model = models.PostedFromTbl
        fields = "__all__"


class PostedFromTblAdmin(admin.ModelAdmin):
    form = PostedFromTblAdminForm
    list_display = [
        "created",
        "last_updated",
        "name",
    ]
    readonly_fields = [
        "created",
        "last_updated",
        "name",
    ]


class PostingAdminForm(forms.ModelForm):

    class Meta:
        model = models.Posting
        fields = "__all__"


class PostingAdmin(admin.ModelAdmin):
    form = PostingAdminForm
    list_display = [
        "created_at",
        "updated_at",
        "body",
        "title",
    ]
    readonly_fields = [
        "created_at",
        "updated_at",
        "body",
        "title",
    ]


admin.site.register(models.TagTbl, TagTblAdmin)
admin.site.register(models.PostedFromTbl, PostedFromTblAdmin)
admin.site.register(models.Posting, PostingAdmin)
