from django.contrib import admin
from django import forms

from . import models


class PostAdminForm(forms.ModelForm):

    class Meta:
        model = models.Post
        fields = "__all__"


class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    list_display = [
        "title",
        "created",
        "body",
        "last_updated",
    ]
    readonly_fields = [
        "title",
        "created",
        "body",
        "last_updated",
    ]


admin.site.register(models.Post, PostAdmin)
