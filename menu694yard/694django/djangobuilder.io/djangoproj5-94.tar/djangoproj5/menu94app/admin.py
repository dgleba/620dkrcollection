from django.contrib import admin
from django import forms

from . import models


class MenuItemAdminForm(forms.ModelForm):

    class Meta:
        model = models.MenuItem
        fields = "__all__"


class MenuItemAdmin(admin.ModelAdmin):
    form = MenuItemAdminForm
    list_display = [
        "sortorder",
        "updated",
        "url",
        "name",
        "grouping",
        "created",
        "status",
    ]
    readonly_fields = [
        "sortorder",
        "updated",
        "url",
        "name",
        "grouping",
        "created",
        "status",
    ]


admin.site.register(models.MenuItem, MenuItemAdmin)
