from django.views import generic
from django.urls import reverse_lazy
from . import models
from . import forms


class MenuItemListView(generic.ListView):
    model = models.MenuItem
    form_class = forms.MenuItemForm


class MenuItemCreateView(generic.CreateView):
    model = models.MenuItem
    form_class = forms.MenuItemForm


class MenuItemDetailView(generic.DetailView):
    model = models.MenuItem
    form_class = forms.MenuItemForm


class MenuItemUpdateView(generic.UpdateView):
    model = models.MenuItem
    form_class = forms.MenuItemForm
    pk_url_kwarg = "pk"


class MenuItemDeleteView(generic.DeleteView):
    model = models.MenuItem
    success_url = reverse_lazy("menu94app_MenuItem_list")
