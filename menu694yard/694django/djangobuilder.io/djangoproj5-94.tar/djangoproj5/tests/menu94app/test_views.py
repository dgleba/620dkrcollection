import pytest
import test_helpers

from django.urls import reverse


pytestmark = [pytest.mark.django_db]


def tests_MenuItem_list_view(client):
    instance1 = test_helpers.create_menu94app_MenuItem()
    instance2 = test_helpers.create_menu94app_MenuItem()
    url = reverse("menu94app_MenuItem_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_MenuItem_create_view(client):
    parent = test_helpers.create_self()
    url = reverse("menu94app_MenuItem_create")
    data = {
        "sortorder": 1,
        "url": "text",
        "name": "text",
        "grouping": "text",
        "status": 1,
        "parent": parent.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_MenuItem_detail_view(client):
    instance = test_helpers.create_menu94app_MenuItem()
    url = reverse("menu94app_MenuItem_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_MenuItem_update_view(client):
    parent = test_helpers.create_self()
    instance = test_helpers.create_menu94app_MenuItem()
    url = reverse("menu94app_MenuItem_update", args=[instance.pk, ])
    data = {
        "sortorder": 1,
        "url": "text",
        "name": "text",
        "grouping": "text",
        "status": 1,
        "parent": parent.pk,
    }
    response = client.post(url, data)
    assert response.status_code == 302
