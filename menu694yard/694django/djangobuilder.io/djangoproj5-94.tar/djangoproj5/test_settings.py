
from djangoproj5.settings import *  # noqa

# Override any settings required for tests here
